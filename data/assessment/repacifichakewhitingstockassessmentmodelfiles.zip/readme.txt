These files are the base input files used for the 2024 Pacific Hake/Whiting stock assessment.  Stock Synthesis (Methot and Wetzel, 2013) version 3.30.22
was the modeling platform used.  The assessment uses a Bayesian framework for estimation, and was implemented using the adnuts R package (Monnahan
and Kristensen, 2018). Refer to section 3.2 of the stock assessment document for more information.
